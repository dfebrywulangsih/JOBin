<?php 
//$koneksi = mysqli_connect("hostname","username","password","nama_database");
$koneksi = mysqli_connect("localhost","root","","jobindb");
?>